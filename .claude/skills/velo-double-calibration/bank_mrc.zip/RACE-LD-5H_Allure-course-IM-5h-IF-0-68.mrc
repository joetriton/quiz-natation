[COURSE HEADER]
VERSION = 2
UNITS = ENGLISH
DESCRIPTION = ~4h40 continu à 66-70% FTP. Simulation longue de la partie vélo IM. | Qualités : Spécifique course (allure cible, gestion d'effort, nutrition) + Durabilité / résistance à la fatigue (tenue de puissance). Double calibration %FTP + RPE.
FILE NAME = RACE-LD-5H Allure course IM ~5h (IF 0.68)
MINUTES PERCENT
[END COURSE HEADER]
[COURSE DATA]
0.00	50.0
10.00	72.0
10.00	68.0
270.00	68.0
270.00	60.0
278.00	45.0
[END COURSE DATA]
[COURSE TEXT]
0	Échauffement progressif — RPE 2->4	600
600	Allure IM 66-70% FTP · RPE 3-4 · IF 0.68 — nutrition / pacing	15600
16200	Retour au calme — RPE 2	480
[END COURSE TEXT]
